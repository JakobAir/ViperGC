GCOS drivecodes courtesy of GCOS team (thanks emu_kidid).

Inject the drivecode corresponding to your drive version (Configuration Menu -> Version Info).

