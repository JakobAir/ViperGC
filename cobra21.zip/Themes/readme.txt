Blackicon theme courtesy of neveruponatime

Check http://nintenskinz.tehskeen.com to download more themes (or submit yours)