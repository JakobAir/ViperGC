Xtreme Finder v1.0 by SlideR/LOONYCUBE - For our friends @ MENTALCUBE!

This tool lets you find cheat codes in games, thanks to Cobra 2.0 game remote interface.

Requires Cobra 2.X and a Viper USB adapter.