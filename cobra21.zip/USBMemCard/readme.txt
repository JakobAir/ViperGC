-----------------------------
--  USBMemCard 1.0 -  Tactics
-----------------------------

Introduction:

  USBMemCard is a program (two, in fact) intended to
backup the contents of the GameCube memory card through
the Viper Extreme's USB connection.


Usage:

  First run USBMemCardGC.DOL in the GC, then run
USBMemCard.exe in the PC. The operation is on the
PC side, through a simple text-only menu. The
options are pretty much self-explanatory.
  To send the DOL file, the preferred way (and the only
one tested up to this point) is using the Viper
application DolSendUsb.


Development Notes:

  This project was developed based on SoftDev's version
of GenPlus, and so it's also an open source project. In
fact, SoftDev's source-only initiative is what motivated
me to setup my development environment. I still use their
makefile too. So, many thanks to the SoftDev team.
  To access the memory card, I used a slightly modified
version of the libogc (20050812 version). I needed a way
to change the gamecode and the company code on-the-fly,
so I created a new function called CARD_ReInit. To
manipulate the 64 bytes of the file's directory entry, I
created two more fuctions, CARD_GetRawStatus and 
CARD_SetRawStatus. Bundled are the modified files and a
already compiled libogc.a.
  I wish I had commented the code a bit better, so other
people could learn a little bit with the stuff I had to 
put together in this project.


Legal notes:
  USBMemCard is based in part on the work of the devkitpro
project (http://sourceforge.net/projects/devkitpro).
Since libogc was modified, this is considered a derivative
work, and so this is under GPL as well. This application's
source code and libogc' modified files must be bundled and
distributed with it.


Contacts:
  http://paginas.terra.com.br/informatica/usbmemcard/
  usbmemcard@gmail.com
  
  