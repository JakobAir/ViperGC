/*............................................................................*/
/* BIN LOADER FOR VIPER GC VERSION 1.0 (C) BY ROMANO M. 2004                  */
/* USE THIS CODE FREELY IN YOUR VIPER GC APPS                                 */
/*............................................................................*/

#include "viper.h"

#define PAD_X         0x04000000
#define BIN_LOCATION  0x80003100
#define PROG_IN_FLASH 0x2000

void PadInit()
{
    int i;
    *(volatile unsigned long*) 0xCC002000 = 0x0F060001;
    *(volatile unsigned long*) 0xCC006400 = 0x00400300; 
    *(volatile unsigned long*) 0xCC00640C = 0x00400300;
    *(volatile unsigned long*) 0xCC006418 = 0x00400300;
    *(volatile unsigned long*) 0xCC006424 = 0x00400300;        
    *(volatile unsigned long*) 0xCC006430 = 0x000701f0; 
    *(volatile unsigned long*) 0xCC006438 = 0x80000000; 
    while (!((*(volatile unsigned long*) 0xCC006438)&0x20000000));
}

void VideoIdle()
{
    *(volatile unsigned long*) 0xCC002000 = 0x00000003;
}

unsigned long PadRead(int channel)
{
    int i,j;
    i=*(volatile unsigned long*) 0xCC006404+12*channel;
    j=*(volatile unsigned long*) 0xCC006408+12*channel;
    return i;
}


int main()
{
    ViperInit(); // Initialize Viper GC Extended mode, takes 1 or 2 seconds.

    int i;                             
    PadInit();
    if (!(PadRead(0) & PAD_X))
    {
        VideoIdle();
        for (i=0;i<128*1024;i++)
            *(unsigned char*)(BIN_LOCATION+i) = 
            *(unsigned char*)(ADDR_VIPER_FLASH+PROG_IN_FLASH+i);
        return 1;
    }

    return 0;
}


