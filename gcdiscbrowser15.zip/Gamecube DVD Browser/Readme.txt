Gamecube DVD Disc Browser Version 1.5
Released Augest 21st 2003 by Sappharad

// Introduction //
This program allows you to browse through the list of files present on any Gamecube DVD. When this program is loaded with your favorite Gamecube code execution tool, you will be prompted to switch discs and you may then insert which game you'd like to browse. You can switch discs at any time. 

// Useage //
Once the disc you insert is loaded, you can use the following controls to navigate through the disc:

Up arrow - Scroll up at 1x
Down arrow - Scroll down at 1x
Left arrow - Switch to file listing only mode
Right arrow - Switch to file information mode
Analog Stick - Scroll up and down at 3x
Left Trigger - Move to beginning of List.
Right Trigger - Move to end of list.
Start Button - Reset the GC

Navigating directories is not supported, and instead a directory's name will be listed as a file with no ending suffix. It's files will be included in the full directory list.
By default, each disc loads into file listing mode. This mode just lists the files on the disc. In file information mode, below each file, some information about it will be listed. There are 3 columns. The first one lists the location of the filesize in memory when the game is running offset by 0. The second column lists the actual location of the file on the Gamecube DVD. The third column lists the filesize. This information can be used to create Action Replay codes that replace one file with another in games. You can find a guide on how to do this at the following URL:
http://www.sappharad.com/index.php?option=displaypage&Itemid=64&op=file&SubMenu=

The games "Phantasy Star Online Episodes 1&2" and "Phantasy Star Online Episode 3" have been blocked from accessing file information mode. This is to prevent people from creating Action Replay codes that unbalance the game's item system by replacing files to offer different items at the wrong time or place that the game normally wouldn't allow.

// Important Note //
This program does NOT enable you to copy Gamecube DVD's into your computer, nor will it ever do so. The author of this program does not condone to piracy in any way.

// Known Bugs //
On a few rare occasions, some spots in the file list may display as empty. If this happens, just eject the disc and re-insert it. It should reload fine. When there are blanks in the list, the file information outputted will be incorrect, which is why the disc must be reloaded.

// Special Thanks To //
The following people have somehow helped contriubte to the development of this program. Their names are listed in no particular order:

Costis
Parasyte
DesktopMan
The OpenGC Lib Team
SSilver2k
Torlus

I greatly appreciate all of the work these people have done that may have helped me with the development of this program.

// Final Words //
All of the resources used to create this program were created using free open source development software. No official development resources were used in the creation of this program. All names and trademarks used are copyright their respected owners.

// Version History //
Version 1.0 - Initial Release

Version 1.2 - Added "file information mode" listing memory offset, location and size of files.

Version 1.3 - Fixed a bug which caused filenames containing non-english characters to crash the program. This fix may not work for 100% of all non-english filenames however...

Version 1.4 - Another filename crashing bugfix...

Version 1.5 - Increased disc startup time, some GC's which couldn't read after swapping disc's may work better.