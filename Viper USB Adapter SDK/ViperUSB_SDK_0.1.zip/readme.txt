...............................................................................
    DOCUMENTATION FOR VIPER USB ADAPTER, V0.1
...............................................................................


SWITCHES
========

SW1 OFF : Chip Enabled
SW1 ON  : Chip Disabled
SW2 OFF : Viper USB Mode
SW2 ON  : Viper Programming Mode


SPECS
=====

Viper USB Adapter is using USB Full Speed and is compatible with USB 1.1 and
USB 2.0 ports. The communication is bidirectionnal. Speed is almost the same 
in both directions.

The Viper USB Adapter contains two FIFO (first in, first out), a read FIFO and
a write FIFO. They are buffered on the adapter itself, and on the PC. 
Thanks to its simple interface, it is very easy to use.


IMPORTANT REMARKS
=================

1. Wait a bit after calling ViperInit() or ViperSetMode()

You have to wait a few ms after calling ViperInit() or ViperSetMode() or some
bytes might not be transmitted correctly. A safe value is 100ms. 
"Sleep(100);" does the job just fine.


2. Avoid synchronous acknowledges

Remember that due to the serial nature of USB 1.1 while transfert speed can
be very high, latency is at least 1ms. In the design of your protocol, avoid
the frequent use of synchronous acknowledges to maximize speed.


3. It's recommended to use an handshake sequence to start with

Internal FIFOs of the Viper USB Adapter are not cleared when the GC is shut 
down. The only way to clear them is to call ViperInit() on the PC side. 
Because of the internal buffers, sending a few bytes to the GC will be 
successful even if the GC is not powered on or expecting data.

Because of that, FIFOs can be full even before the GC is powered on. This
can lead to strange behaviours if your program doesn't handle this case
properly.

It is recommended to have some kind of handshake sequence at the beginning
of your USB communication, so you're sure that the data you receive is
from a live PC and not some old data stuck in the FIFO.

Example:  - PC sends 32-bit random number (R)
          - GC sends (R) back
          - PC verifies (R) and sends a "start of transfert signal"

If your application is executed by a BIOS or an application that uses the
Viper USB Adapter, you don't need to follow this recommendation.


4. Optimising data throughput

If speed is a big issue, use big transfert sizes (of more than 1MB)
that are multiple of 63448 bytes.
