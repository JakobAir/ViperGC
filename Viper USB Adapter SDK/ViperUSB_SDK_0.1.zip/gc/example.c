// see viper.h for EXI registers declaration

// Read a byte from PC (non blocking)
// Return: 1 = One byte was read
//         0 = Nothing to read
int USBReceive (unsigned char* c)
{    	  
	EXI_SR = 0x250; // serial
	EXI_DATA = 0xc0000000; // read byte
	EXI_CR = 0x19;  // bidir
	EXI_WAIT_EOT;	
	unsigned int i = EXI_DATA;	
	EXI_SR = 0x0;  
	
	if (i&0x08000000) // read
	{
	    *c=(i>>16)&0xff;
	    return 1;
	} 
	return 0;
}

// Send a byte to PC (non blocking)
// Return: 1 = Byte transmitted successfully
//         0 = Couldn't send byte (FIFO full)
int USBSend (unsigned char c)
{
	EXI_SR = 0x250; // serial
	EXI_DATA = 0xA0000000 | (c<<20); // write byte
	EXI_CR = 0x19;  // bidir
	EXI_WAIT_EOT;    	
	unsigned int i = EXI_DATA;	
	EXI_SR = 0x0;  
	
	if (i&0x04000000)
	    return 1;    
	    
    return 0;	
}
