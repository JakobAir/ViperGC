/*............................................................................*/
/* UTILITY FUNCTIONS FOR VIPER USB ADAPTER, VERSION 1.0 (C) BY ROMANO M. 2005 */
/*............................................................................*/

#ifndef __VIPERUSB__
#define __VIPERUSB__

// VIPERUSB_EXPORTS is only defined when compiling VIPERUSB.DLL
#ifdef VIPERUSB_EXPORTS
#define VIPERUSB_API __declspec(dllexport)
#else
#define VIPERUSB_API __declspec(dllimport)
#endif

#define VIPERUSB_MODE_USB_ADAPTER         1
#define VIPERUSB_MODE_PROGRAMMER          2
#define VIPERUSB_MODE_PROGRAMMER_SLOW     3

#define VIPERUSB_ERROR_OK                 0
#define VIPERUSB_ERROR_GENERIC           -1
#define VIPERUSB_ERROR_INVALID_PARAMETER -2
#define VIPERUSB_ERROR_DRIVER            -3
#define VIPERUSB_ERROR_ADAPTER_NOT_FOUND -4
#define VIPERUSB_ERROR_NOT_OPEN          -5

typedef unsigned int	VIPERUSB_STATUS;

// open the device in usb adapter mode, reset device, reset timeouts
VIPERUSB_API VIPERUSB_STATUS ViperOpen();

// close device
VIPERUSB_API VIPERUSB_STATUS ViperClose();

// read data from GC
VIPERUSB_API VIPERUSB_STATUS ViperRead(LPVOID lpBuffer, DWORD dwBytesToRead, LPDWORD lpdwBytesReturned);

// send data to GC
VIPERUSB_API VIPERUSB_STATUS ViperWrite(LPVOID lpBuffer, DWORD dwBytesToWrite, LPDWORD lpdwBytesWritten);

// set timeouts (0 = no timeout)
VIPERUSB_API VIPERUSB_STATUS ViperSetReadTimeout(DWORD dwTimeoutInMs);
VIPERUSB_API VIPERUSB_STATUS ViperSetWriteTimeout(DWORD dwTimeoutInMs);

// the following calls are used for programming the chip, don't use them.
VIPERUSB_API VIPERUSB_STATUS ViperSetMode(DWORD dwMode);
VIPERUSB_API VIPERUSB_STATUS ViperProgrammerRead(PUCHAR pucData);
VIPERUSB_API VIPERUSB_STATUS ViperProgrammerWrite(LPVOID lpBuffer, DWORD dwSequentialBytesToWrite, LPDWORD lpdwBytesWritten);


#endif